
![paperbackteaser](https://github.com/user-attachments/assets/2d7b8951-debf-4ce1-8d15-ceb0a685444b)

# Paperback :: Jokers & Consumables :: Steamodded v1.0.0+

A vanilla centered mod built upon expanding the base game (original idea and art by PaperMoon)

Join the [Discord Server](https://discord.gg/uhqx4Yr33j) for updates on the mod progress.

Take a look at the [Wiki Page](https://balatromods.miraheze.org/wiki/Paperback) for an interactive description of the mod!

See [spreadsheet with progress](https://docs.google.com/spreadsheets/d/1PASVdFEUthutKjdsQ8aZ0w863nwBcSf285EYwWuR1lQ/edit?usp=drivesdk) to see all the content that is currently planned for the mod!

See [Releases](https://github.com/GitNether/paperback/releases) for the official working releases.

For the alpha-pre-release-testing-proceed-at-your-own-risk version, simply [download the .zip from the beta branch](https://github.com/GitNether/paperback/archive/refs/heads/beta.zip) or clone the beta branch for easy updating in the future.
