return {
  descriptions = {
    Back = {
      b_paperback_paper = {
        name = "紙質牌組",
        text = {
          "{C:legendary}Paperback{C:attention}小丑{}有{C:attention}3x",
          "更可能出現"
        }
      },
      b_paperback_proud = {
        name = "驕傲牌組",
        text = {
          "開局時擁有全套的",
          "{C:hearts}紅桃{}、{C:diamonds}方片{}、{C:spades}黑桃",
          "{C:clubs}梅花{}、{C:paperback_crowns}皇冠{}、{C:paperback_stars}銀星"
        }
      },
      b_paperback_silver = {
        name = "銀色牌組",
        text = {
          "開局時擁有",
          "{C:paperback_minor_arcana,T:v_paperback_celtic_cross}#1#{}優惠券",
          "和一張{C:paperback_minor_arcana,T:c_paperback_nine_of_cups}#2#"
        }
      }
    },
    Joker = {
      j_paperback_festive_joker = {
        name = "喜慶小丑",
        text = {
          "{C:attention}#1#{}在計分時",
          "有{C:green}#2#/#3#幾率創造",
          "一張隨機{C:attention}消耗牌{}",
          "{C:inactive}(需要空間)"
        }
      },
      j_paperback_medic = {
        name = "醫生",
        text = {
          "{C:attention}#1#{}重新觸發",
          "其他牌的效果增加一次",
        }
      },
      j_paperback_matcha = {
        name = "抹茶",
        text = {
          "每張牌計分時這張",
          "小丑獲得{C:chips}+#1#{}籌碼",
          "{C:mult}棄牌{}時有",
          "{C:green}#2#/#3#{}幾率自毀",
          "{C:inactive}(當前{C:chips}+#4#{C:inactive}籌碼)"
        }
      },
      j_paperback_you_are_a_fool = {
        name = "你是小丑！",
        text = {
          "如果出牌至少有",
          "{C:attention}#1#{}張{C:attention}人頭牌{}計分",
          "將{C:attention}留在手牌中{}的所有牌",
          "轉換為{C:attention}最左側{}的計分牌",
          "{S:1.1,C:red,E:2}之後自毀",
        }
      },
      j_paperback_kintsugi_joker = {
        name = "金繕小丑",
        text = {
          "當一張{C:attention}#2#{}被摧毀時",
          "將{C:attention}#2#{}的資金",
          "產出上限提升{C:money}$#1#{}",
          "{C:inactive}(當前提升{C:money}$#3#{C:inactive})"
        }
      },
      j_paperback_ddakji = {
        name = "疊紙遊戲",
        text = {
          "{C:green}#1#/#2#{}的牌抽取時背面朝上",
          "如果打出的計分牌同時",
          "包含{C:attention}正面朝上{}和",
          "{C:attention}背面朝上{}的牌",
          "創造一張隨機消耗牌",
          "{C:inactive}(需要空間)"
        }
      },
      j_paperback_weather_radio = {
        name = "天氣預報",
        text = {
          "如果打出的{C:attention}牌型{}包含{C:attention}#2#{}",
          "這張小丑獲得{X:mult,C:white}X#1#{}倍率",
          "當達到{X:mult,C:white}X#3#{}倍率或以上時",
          "消除當前{C:attention}Boss盲注{}的限制條件",
          "並失去{X:mult,C:white}X#4#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#5#{C:inactive}倍率)",
          "{s:0.75}牌型每回合結束改變"
        }
      },
      j_paperback_power_surge = {
        name = "電湧",
        text = {
          "打出的{C:attention}#1#{}在計分時",
          "給予{X:mult,C:white}X#2#{}倍率",
          "但有{C:green}#3#/#4#{}幾率",
          "{C:red}摧毀{}一張{C:attention}留在{}",
          "{C:attention}手牌中{}的卡牌",
        }
      },
      j_paperback_bismuth = {
        name = "鉍",
        text = {
          "打出的{V:1}#1#{}和{V:2}#2#{}花色牌",
          "有{C:green}#3#/#4#{}概率變成",
          "{C:dark_edition}閃箔{}、{C:dark_edition}鐳射{}或{C:dark_edition}多彩",
        }
      },
      j_paperback_deadringer = {
        name = "牽線傀儡",
        text = {
          "重新觸發計分的{C:attention}#1#{}和{C:attention}#2#",
          "重新觸發計分的{C:attention}#3#{}兩次"
        }
      },
      j_paperback_full_moon = {
        name = "滿月",
        text = {
          "{C:planet}星球牌{}有",
          "{C:green}#1#/#2#{}幾率",
          "升級{C:attention}兩次",
        }
      },
      j_paperback_sake_cup = {
        name = "清酒杯",
        text = {
          "每次出牌{C:attention}留在手牌中{}",
          "的{C:attention}#1#{}有{C:green}#2#/#3#{}幾率創造",
          "一張{C:attention}對應牌型{}的{C:planet}星球牌",
          "{C:inactive}(需要空間)"
        }
      },
      j_paperback_resurrections = {
        name = "復活",
        text = {
          "賣掉{C:attention}小丑{}時有{C:green}#1#/#2#{}幾率",
          "創造一張售價{C:money}-$#3#{}且帶有",
          "{C:dark_edition}負片{}版本的相同小丑",
          "{s:0.9}複製失敗時幾率增加{s:0.9,C:green}#4#",
          "{s:0.9}複製成功後幾率重置"
        }
      },
      j_paperback_book_of_vengeance = {
        name = "復仇之書",
        text = {
          "如果回合的{C:attention}第一次出牌{}",
          "擊敗了{C:attention}Boss盲注{}",
          "自毀並複製一張",
          "右側的{C:attention}小丑{}"
        }
      },
      j_paperback_b_soda = {
        name = "B-蘇打",
        text = {
          "選擇{C:attention}盲注{}時",
          "獲得{C:chips}+#1#{}出牌次數",
          "擊敗{C:attention}盲注{}時若",
          "剩餘{C:chips}0{}出牌次數",
          "則回合結束自毀",
        }
      },
      j_paperback_angel_investor = {
        name = "天使投資家",
        text = {
          "跳過{C:attention}盲注{}時獲得",
          "{C:attention}#1#{}個{C:money}天使投資標籤"
        }
      },
      j_paperback_ice_cube = {
        name = "冰塊",
        text = {
          "每個{C:attention}食物小丑{}",
          "提供{X:mult,C:white}X#1#{}倍率",
          "{C:attention}#2#{}回合後融化",
          "{C:inactive}(當前{X:mult,C:white}X#3#{C:inactive}倍率)"
        }
      },
      j_paperback_champagne = {
        name = "香檳",
        text = {
          "挑戰{C:attention}Boss盲注{}期間",
          "每張計分牌給予{C:money}$#1#{}",
          "帶有{C:attention}蠟封{}的牌{C:attention}翻倍{}",
          "{C:attention}#2#{}回合後{C:attention}飲盡{}"
        }
      },
      j_paperback_pocket_pair = {
        name = "便攜對子",
        text = {
          "回合開始發牌發出的",
          "每一個{C:attention}#2#{}給予{C:money}$#1#{}"
        }
      },
      j_paperback_the_quiet = {
        name = "這寧靜",
        text = {
          "在你的完整牌組中",
          "每比完整的{C:attention}#2#{}張牌少一張",
          "就獲得{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#3#{C:inactive}倍率)"
        }
      },
      j_paperback_alert = {
        name = "警報",
        text = {
          "如果{C:attention}出牌{}是",
          "一張{C:attention}人頭牌{},",
          "將其摧毀",
          "{C:inactive}(#1#/#2#)?"
        }
      },
      j_paperback_legacy = {
        name = "遺產",
        text = {
          "當摧毀一張{C:attention}無增強{}的牌時",
          "將它的{C:chips}籌碼{}數作為{C:mult}倍率{}",
          "增加到這張牌的倍率上",
          "{C:inactive}(當前{C:mult}+#1#{C:inactive}倍率)"
        }
      },
      j_paperback_backpack = {
        name = "背包",
        text = {
          "{C:money}商店{}增加一個",
          "免費的{C:attention}小丑包"
        }
      },
      j_paperback_jester_of_nihil = {
        name = "虛無弄臣",
        text = {
          "{C:attention}削弱最後計分{}的牌",
          "對應的花色",
          "每張{C:attention}被削弱{}的牌",
          "給予{C:mult}+#1#{}倍率",
          "{C:inactive}(當前削弱{V:1}#2#{C:inactive}且{C:mult}+#3#{C:inactive}倍率)",
        }
      },
      j_paperback_forgery = {
        name = "贗品",
        text = {
          "每次出牌複製一張隨機{C:attention}小丑的能力",
          "如果其中包含{X:mult,C:white}X倍率{}、{C:mult}倍率{}或{C:chips}籌碼{}",
          "將對應的數值乘以",
          "{X:attention,C:white}X#1#{}與{X:attention,C:white}X#2#{}之間的隨機係數",
          "{C:inactive}(當前{C:attention}#3#{C:inactive}係數{X:attention,C:white}X#4#{C:inactive})"
        }
      },
      j_paperback_the_world = {
        name = "砸瓦魯多",
        text = {
          "所有{C:chips}出牌{}和{C:mult}棄牌{}",
          "都視為每回合",
          "{C:attention}第一次{}和{C:attention}最後一次{}"
        }
      },
      j_paperback_epic_sauce = {
        name = "史詩醬料",
        text = {
          "{X:mult,C:white}X#1#{}倍率",
          "如果出牌不是",
          "回合{C:attention}第一次{}出牌",
          "摧毀一張隨機{C:attention}小丑{}"
        }
      },
      j_paperback_find_jimbo = {
        name = "視覺大發現",
        text = {
          "每張計分的{V:1}#2#{}{C:attention}#1#{}",
          "使你獲得{C:money}$#3#{}",
          "{s:0.8}卡牌每回合改變"
        },
      },
      j_paperback_cream_liqueur = {
        name = "奶油利口酒",
        text = {
          "{C:attention}標籤{}生效時賺取{C:money}$#1#{}",
          "{C:attention}#2#{}回合後{C:attention}飲盡{}",
          "{C:inactive}(獲取{C:attention}標籤{C:inactive}時重置)"
        }
      },
      j_paperback_coffee = {
        name = "咖啡",
        text = {
          "{C:attention}+#1#{}手牌上限",
          "跳過{C:attention}盲注{}時增加{C:attention}#2#{}",
          "選擇{C:attention}小盲注{}或{C:attention}大盲注{}時",
          "有{C:green}#3#/#4#{}幾率{C:attention}飲盡{}",
        }
      },
      j_paperback_basic_energy = {
        name = "基本小丑能量",
        text = {
          "使用任何{C:attention}消耗牌{}時",
          "有{C:green}#1#/#2#{}幾率複製一張",
          "{C:inactive}(無法複製複製出的牌)",
          "{C:inactive}(需要空間)"
        }
      },
      j_paperback_big_misser = {
        name = "莫大的缺失",
        text = {
          "每個空的消耗牌槽位",
          "獲得{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#2#{}{C:inactive}倍率)"
        }
      },
      j_paperback_complete_breakfast = {
        name = "均衡早餐",
        text = {
          "{C:mult}+#1#{}倍率且{C:chips}+#2#{}籌碼",
          "出牌後這張小丑",
          "有{C:green}#3#/#4#{}幾率{C:attention}吃完{}",
          "出牌後幾率",
          "增加{C:attention}#5#{}",
        },
      },
      j_paperback_emergency_broadcast = {
        name = "緊急廣播",
        text = {
          "打出的{C:attention}5{}和{C:attention}8{}計分時",
          "給予{C:mult}+#1#{}倍率和{C:chips}+#2#{}籌碼",
        },
      },
      j_paperback_moribund = {
        name = "行將就木",
        text = {
          "如果擊敗{C:attention}盲注{}時",
          "剩餘{C:chips}出牌次數{}為{C:attention}0",
          "這張小丑獲得{C:mult}+#1#{}倍率",
          "沒有擊敗盲注則{C:mult}倍率{}翻倍",
          "{C:inactive}(當前{C:mult}+#2#{C:inactive}倍率)",
        },
      },
      j_paperback_crispy_taco = {
        name = "酥脆玉米卷",
        text = {
          "{X:chips,C:white}X#1#{}籌碼",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_furioso = {
        name = "Furioso",
        text = {
      	"計分的每個不同{C:attention}點數{}",
          "使這張小丑獲得{X:mult,C:white}X#1#{}倍率",
          "擊敗{C:attention}Boss盲注{}後重置",
          "{C:inactive}(當前{X:mult,C:white}X#2#{}{C:inactive}倍率)",
          "{C:inactive}(打出總點數：{C:attention}#3#{C:inactive})",
        },
      },
      j_paperback_soft_taco = {
        name = "綿軟玉米卷",
        text = {
          "{X:mult,C:white}X#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_charred_marshmallow = {
        name = "焦黃棉花糖",
        text = {
          "計分的{C:spades}黑桃{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_joker_cookie = {
        name = "小丑姜餅",
        text = {
          "回合結束時賺取{C:money}$#1#{}",
          "提現時這一數值增加{C:money}$#2#{}",
          "回合結束時",
          "有{C:green}#3#/#4#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_pop_stick = {
        name = "棒簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_pool_table = {
        name = "檯球桌",
        text = {
          "如果回合的第一次出牌",
          "不包含計分的{C:attention}人頭牌{}",
          "創造一張對應{C:attention}牌型",
          "的{C:planet}星球牌",
          "{C:inactive}(需要空間)",
        },
      },
      j_paperback_bicycle = {
        name = "自行車",
        text = {
          "{C:attention}萬能牌{}給予等同於",
          "其{C:chips}籌碼{}數的{C:mult}倍率{}",
          "之後{X:mult,C:white}X#1#{}倍率",
        },
      },
      j_paperback_stamp = {
        name = "郵戳",
        text = {
          "任何帶有{C:attention}蠟封{}的牌計分時",
          "這張小丑有{C:green}#1#/#2#{}幾率",
          "獲得{C:chips}+#3#{}籌碼",
          "{C:inactive}(當前{C:chips}+#4#{C:inactive}籌碼)",
        },
      },
      j_paperback_sticky_stick = {
        name = "黏簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_shopping_center = {
        name = "購物中心",
        text = {
          "{C:money}商店{}增加一個",
          "額外{C:attention}卡牌槽位",
        },
      },
      j_paperback_ghost_cola = {
        name = "幽靈可樂",
        text = {
          "賣掉這張小丑以創造一個{C:attention}#1#{}",
          "和一張隨機{C:dark_edition}負片{}{C:spectral}幻靈牌{}",
        },
      },
      j_paperback_river = {
        name = "河流",
        text = {
          "如果打出的牌包含{C:attention}5張計分牌",
          "獲得等同於得分最低的",
          "卡牌的{C:chips}籌碼{}的{C:money}資金",
          "{C:inactive}(最高{C:money}$#1#{C:inactive})",
        },
      },
      j_paperback_solemn_lament = {
        name = "莊嚴哀悼",
        text = {
          "每個剩餘的{C:chips}出牌{}和",
          "{C:mult}棄牌{}次數使每次出牌",
          "的{C:attention}第一張{}計分牌",
          "重新觸發一次"
        },
      },
      j_paperback_hole_in_one = {
        name = "一杆進洞",
        text = {
          "如果回合的{C:chips}第一次出牌{}擊敗了{C:attention}盲注{}",
          "則將所有{C:attention}卡牌{}的{C:attention}出售價格{}翻倍",
          "{C:inactive}(最多每回合{C:money}$#1#{C:inactive})",
          "這張小丑被售出時將",
          "{C:attention}所有卡牌{}的{C:attention}售價{}設為{C:money}$0"
        },
      },
      j_paperback_mismatched_sock = {
        name = "錯配襪子",
        text = {
      	"如果打出的牌中",
          "不包含{C:attention}#2#",
          "這張小丑獲得{X:mult,C:white}X#1#倍率",
          "{C:inactive}(當前{X:mult,C:white}X#3#{C:inactive}倍率)",
        },
      },
      j_paperback_quick_fix = {
        name = "應急補丁",
        text = {
          "{C:attention}+#1#{}手牌上限",
          "回合結束",
          "有{C:green}#2#/#3#{}幾率",
          "自毀",
        },
      },
      j_paperback_skydiver = {
        name = "跳傘者",
        text = {
          "如果本次出牌所有{C:attention}計分牌{}的點數",
          "均不大於本回合計分過的{C:attention}最小點數",
          "獲得{C:white,X:mult}X#1#{}倍率",
          "{C:inactive}(出牌結束後更新{C:inactive})",
          "{C:inactive}(當前點數：{C:attention}#2#{C:inactive})",
        },
      },
      j_paperback_surfer = {
        name = "飆網者",
        text = {
          "{C:attention}回合結束時{}每張留在手牌中",
          "的{C:attention}#3#{}使這張小丑獲得{C:chips}+#1#{}籌碼",
          "每張計分的{C:attention}#3#{}使",
          "這張小丑獲得{C:chips}+#2#{}籌碼",
          "{C:inactive}(當前{C:chips}+#4#{C:inactive}籌碼)"
        }
      },
      j_paperback_blue_bonnets = {
        name = "矢車菊",
        text = {
          "計分的{C:clubs}梅花{}花色牌給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:clubs}梅花{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
      j_paperback_great_wave = {
        name = "巨浪",
        text = {
          "打出的{C:attention}每張牌{}使{C:attention}最右側{}",
          "的計分牌{C:attention}重新觸發{}一次",
        },
      },
      j_paperback_caramel_apple = {
        name = "焦糖蘋果",
        text = {
          "計分的{C:clubs}梅花{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_nachos = {
        name = "烤乾酪辣味玉米片",
        text = {
          "{X:chips,C:white}X#1#{}籌碼",
          "每棄{C:attention}一張{}牌",
          "失去{X:chips,C:white}X#2#{}籌碼",
        },
      },
      j_paperback_pride_flag_spectrums = {
        name = "自豪旗幟",
        text = {
          "如果打出的牌中包含{C:attention}光譜",
          "這張小丑獲得{C:chips}+#1#{}籌碼",
          "如果打出的牌包含{C:attention}順子",
          "則會重置",
          "{C:inactive}(當前{C:chips}+#2#{}{C:inactive}籌碼)"
        },
      },
      j_paperback_pride_flag_no_spectrums = {
        name = "自豪旗幟",
        text = {
          "如果打出的牌中包含",
          "{C:attention}三種{}不同花色",
          "這張小丑獲得{C:mult}+#1#{}倍率",
          "{C:inactive}(當前{C:mult}+#2#{}{C:inactive}倍率)",
        },
      },
      j_paperback_sacrificial_lamb = {
        name = "替罪羊",
        text = {
          "每{C:attention}摧毀{}一張卡牌或小丑",
          "這張小丑獲得{C:mult}+#1#{}倍率",
          "{C:inactive}(當前{C:mult}+#2#{C:inactive}倍率)",
        },
      },
      j_paperback_autumn_leaves = {
        name = "秋葉",
        text = {
          "計分的{C:diamonds}方片{}花色牌給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:diamonds}方片{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
      j_paperback_wild_prize = {
        name = "[[萬能大獎!1!]]",
        text = {
          "{C:attention}萬能牌{}有{C:green}#1#/#2#{}幾率",
          "{C:attention}重新觸發{}以及{C:green}#1#/#3#{}幾率",
          "計分時賺取{C:money}$#4#{}到{C:money}$#5#{}",
        },
      },
      j_paperback_wish_you_were_here = {
        name = "想你在這裡",
        text = {
          "獲得等同于這張小丑",
          "{C:attention}售價{}{C:mult}#1#X{}倍的{C:mult}倍率{}",
          "回合結束時",
          "{C:attention}售價{}提升{C:money}$#2#{}",
          "{C:inactive}(當前{C:mult}+#3#{C:inactive}倍率){}",
        },
      },
      j_paperback_calling_card = {
        name = "預告信",
        text = {
          "擊敗{C:attention}Boss盲注{}或",
          "觸發它的{C:attention}限制{}時",
          "這張小丑獲得{X:red,C:white}X#1#{}倍率",
          "{C:inactive}(當前{}{X:red,C:white}X#2#{}{C:inactive}倍率){}",
        },
      },
      j_paperback_subterfuge = {
        name = "詭計",
        text = {
          "摧毀每回合打出的",
          "{C:attention}第一手牌{}"
        },
      },
      j_paperback_triple_moon_goddess = {
        name = "三月女神",
        text = {
          "如果打出的牌中包含{C:attention}三條{}",
          "有{C:green}#1#/#2#{}幾率創造一張隨機{C:planet}星球牌{}",
          "有{C:green}#1#/#3#{}幾率創造一張隨機{C:purple}塔羅牌{}",
          "{C:inactive}(需要空間)"
        },
      },
      j_paperback_triple_moon_goddess_minor_arcana = {
        name = "三月女神",
        text = {
          "如果打出的牌中包含{C:attention}三條{}",
          "有{C:green}#1#/#2#{}幾率創造一張隨機{C:tarot}塔羅牌{}",
          "有{C:green}#1#/#3#{}幾率創造一張隨機{C:paperback_minor_arcana}塔羅輔牌{}",
          "{C:inactive}(需要空間)"
        },
      },
      j_paperback_derecho = {
        name = "橫行風暴",
        text = {
          "如果打出的{C:attention}計分牌{}僅包含{C:paperback_dark_suit}暗花色",
          "這張小丑獲得{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_jestrica = {
        name = "JESTRiCA",
        text = {
          "打出的{C:attention}8{}計分時",
          "這張小丑獲得{C:mult}+#1#{}倍率",
          "本回合未觸發則重置",
          "{C:inactive}(當前C:mult}+#2#{C:inactive}倍率)"
        },
      },
      j_paperback_grand_strategy = {
        name = "大戰略",
        text = {
          "如果牌組中至少有{C:attention}#2#{}種",
          "不同的{C:attention}增強{}、{C:attention}版本{}、{C:attention}蠟封{}",
          "則{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{C:attention}#3#{C:inactive})",
        },
      },
      j_paperback_solar_system = {
        name = "太陽系",
        text = {
          "九種基礎{C:planet}星球{}中",
          "{C:attention}等級{}最低的那個",
          "按等級每級提供{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#2#{}{C:inactive}倍率)",
        },
      },
      j_paperback_reference_card = {
        name = "參考卡",
        text = {
          "九種基礎{C:attention}牌型{}中",
          "{C:attention}打出次數{}最少的那個",
          "按次數每次提供{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#2#{}{C:inactive}倍率)",
        },
      },
      j_paperback_dreamsicle = {
        name = "夢幻冰棒",
        text = {
          "計分的{C:diamonds}方片{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_jimbo_adventure = {
        name = "小丑大冒險",
        text = {
          "跳過{C:attention}盲注{}時創造",
          "一個隨機的{C:attention}標籤{}",
        },
      },
      j_paperback_union_card = {
        name = "聯盟卡",
        text = {
          "持有這張小丑時所有",
          "{C:attention}卡牌{}的{C:attention}售價{}鎖定為{C:money}$0{}",
          "給予等同於本次出牌中",
          "計分的{C:paperback_light_suit}亮花色{}卡牌數量",
          "的{X:mult,C:white}X倍率{}",
        },
      },
      j_paperback_cherry_blossoms = {
        name = "櫻花",
        text = {
          "計分的{C:hearts}紅桃{}花色牌給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:hearts}紅桃{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
      j_paperback_paranoia = {
        name = "偏執狂",
        text = {
          "本局中{C:attention}摧毀{}的每張",
          "{C:paperback_dark_suit}暗花色{}卡牌使打出的",
          "{C:paperback_light_suit}亮花色{}卡牌每張提供{C:mult}+#1#{}倍率",
          "{C:inactive}(當前{C:mult}+#2#{C:inactive}倍率)"
        },
      },
      j_paperback_unholy_alliance = {
        name = "邪惡聯盟",
        text = {
      	"每{C:attention}摧毀{}一張卡牌或小丑",
          "這張小丑獲得{X:mult,C:white}X#1#{}倍率",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_summoning_circle = {
        name = "召喚術陣",
        text = {
          "如果打出的牌中",
          "包含{C:attention}#1#{}",
          "複製一張{C:attention}隨機消耗牌",
          "{C:inactive}(需要空間)",
        },
      },
      j_paperback_pointy_stick = {
        name = "尖簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_prince_of_darkness = {
        name = "黑暗王子",
        text = {
          "如果打出的計分牌中",
          "包含{C:hearts}紅桃{}和{C:attention}#1#{}種不同花色",
          "接下來的{C:chips}#3#{}次出牌",
          "這張小丑提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(當前下{C:chips}#4#{C:inactive}次出牌)",
        },
      },
      j_paperback_popsicle_stick = {
        name = "冰簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_let_it_happen = {
        name = "順其自然",
        text = {
          "如果出牌牌型是",
          "本{C:attention}底注{}第一次打出",
          "平衡{C:mult}倍率{}和{C:chips}籌碼",
          "{C:inactive}(已打出的牌型：{C:attention}#1#{C:inactive})",
        },
      },
      j_paperback_evergreens = {
        name = "常青樹",
        text = {
          "計分的{C:spades}黑桃{}花色牌給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:spades}黑桃{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
      j_paperback_cakepop = {
        name = "蛋糕棒棒糖",
        text = {
          "計分的{C:hearts}紅桃{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_black_rainbows = {
        name = "黑彩虹",
        text = {
          "計分的{C:spades}黑桃{}和{C:clubs}梅花",
          "有{C:green}#1#/#2#{}幾率",
          "變成{C:dark_edition}多彩"
        }
      },
      j_paperback_meeple = {
        name = "米寶",
        text = {
          "如果打出的牌中",
          "包含計分的{C:attention}人頭牌{}",
          "本回合{C:mult}+#1#{}棄牌次數",
        }
      },
      j_paperback_apple = {
        name = "蘋果",
        text = {
          "計分的{C:hearts}紅桃{}花色牌",
          "有{C:green}#1#/#2#{}幾率創造",
          "一張{C:dark_edition}負片{C:attention}消耗牌",
          "{S:1.1,C:red,E:2}觸發後自毀",
        }
      },
      j_paperback_heretical_joker = {
        name = "異教小丑",
        text = {
          "打出的",
          "{C:paperback_stars}銀星{}花色牌",
          "在計分時給予{C:mult}+#1#{}倍率",
        },
      },
      j_paperback_fraudulent_joker = {
        name = "欺詐小丑",
        text = {
          "打出的",
          "{C:paperback_crowns}皇冠{}花色牌",
          "在計分時給予{C:mult}+#1#{}倍率",
        },
      },
      j_paperback_rock_candy = {
        name = "石頭糖",
        text = {
          "計分的{C:paperback_stars}銀星{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_rockin_stick = {
        name = "石簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_tanghulu = {
        name = "糖葫蘆",
        text = {
          "計分的{C:paperback_crowns}皇冠{}花色牌",
          "給予{C:mult}+#1#{}倍率",
          "回合結束時",
          "有{C:green}#2#/#3#{}幾率{C:attention}吃完{}",
        },
      },
      j_paperback_sweet_stick = {
        name = "甜簽",
        text = {
          "其他{C:attention}\"簽\"{}小丑",
          "每個提供{X:mult,C:white}X#1#{}倍率...",
          "{C:inactive}(當前{X:mult,C:white}X#2#{C:inactive}倍率)",
        },
      },
      j_paperback_quartz = {
        name = "石英",
        text = {
          "每張打出的{C:paperback_stars}銀星{}花色牌",
          "使其他計分的{C:paperback_stars}銀星{}花色牌",
          "額外給予{X:chips,C:white}X#1#{}籌碼"
        }
      },
      j_paperback_pyrite = {
        name = "黃鐵礦",
        text = {
          "打出的{V:1}#1#{}花色牌",
          "有{C:green}#2#/#3#{}幾率創造",
          "一張隨機{C:tarot}塔羅牌{}",
          "{C:inactive}(需要空間)"
        }
      },
      j_paperback_wheat_field = {
        name = "麥田",
        text = {
          "計分的{C:paperback_crowns}皇冠{}花色牌{}給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:paperback_crowns}皇冠{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
      j_paperback_clothespin = {
        name = "衣夾",
        text = {
          "{C:attention}回合結束{}時每個",
          "{C:attention}留在手牌中{}的{C:attention}別針",
          "使這張小丑獲得{C:chips}+#1#{}籌碼",
          "{C:inactive}(當前{C:chips}+#2#{C:inactive}籌碼)"
        }
      },
      j_paperback_watercolor_joker = {
        name = "水彩小丑",
        text = {
          "{C:attention}#1#{}計分時",
          "給予{X:chips,C:white}X#2#{}籌碼",
        }
      },
      j_paperback_birches = {
        name = "白樺",
        text = {
          "計分的{C:paperback_stars}銀星{}花色牌{}給予{X:mult,C:white}X#1#{}倍率",
          "每張連續打出的{C:paperback_stars}銀星{}花色牌",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)",
        },
      },
    },
    paperback_minor_arcana = {
      c_paperback_ace_of_cups = {
        name = "聖杯A",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:chips}藍色別針{}"
        }
      },
      c_paperback_two_of_cups = {
        name = "聖杯二",
        text = {
          "隨機創造一個",
          "{C:dark_edition}多彩{}、{C:dark_edition}鐳射{}、{C:dark_edition}閃箔{}、",
          "{C:mult}稀有{}或{C:green}罕見{C:attention}標籤"
        }
      },
      c_paperback_three_of_cups = {
        name = "聖杯三",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:paperback_black}黑色別針{}"
        }
      },
      c_paperback_four_of_cups = {
        name = "聖杯四",
        text = {
          "選定最多{C:attention}#1#{}張卡牌",
          "並移除其所有的",
          "{C:attention}增強{}、{C:attention}蠟封{}和{C:attention}版本{}",
          "每移除一個就獲得{C:money}$#2#{}"
        }
      },
      c_paperback_five_of_cups = {
        name = "聖杯五",
        text = {
          "增強{C:attention}#1#{}張選定",
          "卡牌成為",
          "{C:attention}#2#{}"
        }
      },
      c_paperback_six_of_cups = {
        name = "聖杯六",
        text = {
          "獲得等同於所選",
          "{C:attention}#1#{}張卡牌{C:chips}籌碼{}數",
          "{C:attention}一半{}的{C:money}資金",
          "{C:inactive}(最高{C:money}$#2#{C:inactive})"
        }
      },
      c_paperback_seven_of_cups = {
        name = "聖杯七",
        text = {
          "選定最多{C:attention}#1#{}張卡牌",
          "使其獲得隨機{C:attention}增強",
        }
      },
      c_paperback_eight_of_cups = {
        name = "聖杯八",
        text = {
          "選定最多{C:attention}#1#{}張卡牌",
          "將其轉換為{C:attention}當前",
          "{C:attention}未選定{}的一種隨機花色"
        }
      },
      c_paperback_nine_of_cups = {
        name = "聖杯九",
        text = {
          "選定一張{C:attention}小丑{}",
          "將其摧毀並創造一張",
          "相同或更高{C:attention}稀有度{}的{C:attention}小丑{}",
          "{C:inactive}(無法升級為{C:legendary}傳奇{C:inactive})"
        }
      },
      c_paperback_ten_of_cups = {
        name = "聖杯十",
        text = {
          "有{C:green}#1#/#2#{}幾率",
          "為一張所選卡牌",
          "添加{C:dark_edition}多彩{}版本",
        }
      },
      c_paperback_page_of_cups = {
        name = "聖杯侍從",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:inactive}白色別針{}"
        }
      },
      c_paperback_knight_of_cups = {
        name = "聖杯騎士",
        text = {
          "選定{C:attention}#1#{}張卡牌",
          "{C:attention}左側{}那張複製{C:attention}右側{}那張",
          "除了{C:attention}點數{}和{C:attention}花色{}以外的{C:attention}一切{}",
          "之後摧毀{C:attention}右側{}那張",
          "{C:inactive}(拖動重新排列)"
        }
      },
      c_paperback_queen_of_cups = {
        name = "聖杯皇后",
        text = {
          "增強{C:attention}#1#{}張選定",
          "卡牌成為",
          "{C:attention}#2#{}"
        }
      },
      c_paperback_king_of_cups = {
        name = "聖杯國王",
        text = {
          "每個擁有全部13種{C:attention}基礎點數{}",
          "的花色使你獲得{C:money}$#1#{}",
          "{C:inactive}(當前{C:money}$#2#{C:inactive})"
        }
      },
      c_paperback_ace_of_wands = {
        name = "權杖A",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:mult}紅色別針{}"
        }
      },
      c_paperback_two_of_wands = {
        name = "權杖二",
        text = {
          "創造你打出次數",
          "{C:attention}最多{}和{C:attention}最少{}牌型",
          "對應的{C:planet}星球牌{}",
          "{C:inactive}(需要空間)"
        }
      },
      c_paperback_three_of_wands = {
        name = "權杖三",
        text = {
          "選定手牌中的{C:attention}#1#{}張牌",
          "生成1張其複製牌",
        }
      },
      c_paperback_four_of_wands = {
        name = "權杖四",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:paperback_pink}粉色別針{}"
        }
      },
      c_paperback_five_of_wands = {
        name = "權杖五",
        text = {
          "摧毀{C:attention}所有手牌{}",
          "將資金設為{C:money}$0"
        }
      },
      c_paperback_six_of_wands = {
        name = "權杖六",
        text = {
          "增強{C:attention}#1#{}張選定",
          "卡牌成為",
          "{C:attention}#2#{}"
        }
      },
      c_paperback_seven_of_wands = {
        name = "權杖七",
        text = {
          "創造一個{C:attention}攻堅標籤"
        }
      },
      c_paperback_eight_of_wands = {
        name = "權杖八",
        text = {
          "創造一個{C:dark_edition}負片{C:attention}標籤{}並失去{C:money}$#1#{}",
          "如果當前擁有超過{C:attention}#3#{}張小丑",
          "超出的每張使你額外失去{C:money}$#2#{}",
          "{C:inactive}(當前{C:money}$#4#{C:inactive})"
        }
      },
      c_paperback_nine_of_wands = {
        name = "權杖九",
        text = {
          "增強{C:attention}#1#{}張選定",
          "卡牌成為",
          "{C:attention}#2#{}"
        }
      },
      c_paperback_ten_of_wands = {
        name = "權杖十",
        text = {
          "選定{C:attention}#1#{}張卡牌",
          "摧毀{C:attention}右側兩張{}並將",
          "它們的{C:chips}籌碼{}給予{C:attention}左側那張",
          "{C:inactive}(拖動重新排列)"
        }
      },
      c_paperback_page_of_wands = {
        name = "權杖侍從",
        text = {
          "給最多{C:attention}#1#{}張所選卡牌",
          "加上{C:attention}橙色別針{}"
        }
      },
      c_paperback_knight_of_wands = {
        name = "權杖騎士",
        text = {
          "創造一個{C:mult}高風險{C:attention}標籤"
        }
      },
      c_paperback_queen_of_wands = {
        name = "權杖皇后",
        text = {
          "有{C:green}#1#/#2#{}幾率",
          "為一張隨機{C:attention}小丑",
          "添加{C:dark_edition}雙色{}版本"
        }
      },
      c_paperback_king_of_wands = {
        name = "權杖國王",
        text = {
          "創造一張隨機",
          "非{C:chips}普通{C:attention}小丑",
          "{C:inactive}(不包含{C:legendary}傳奇{C:inactive})"
        }
      },
      c_paperback_ace_of_swords = {
        name = "寶劍A",
        text = {
          "將最多{C:attention}#1#{}張",
          "選定卡牌",
          "轉換為{V:1}#2#{}",
        }
      },
      c_paperback_ace_of_pentacles = {
        name = "錢幣A",
        text = {
          "將最多{C:attention}#1#{}張",
          "選定卡牌",
          "轉換為{V:1}#2#{}",
        }
      }
    },
    Voucher = {
      v_paperback_celtic_cross = {
        name = "凱爾特十字",
        text = {
          "擊敗{C:attention}Boss盲注{}時",
          "獲得一個{C:paperback_minor_arcana}占卜標籤{}"
        }
      },
      v_paperback_soothsay = {
        name = "預言",
        text = {
          "{C:money}商店{}裡面",
	  	"有{C:paperback_minor_arcana}塔羅輔牌{}",
  		"可供選購",
        }
      },
    },
    Tag = {
      tag_paperback_angel_investment = {
        name = "天使投資標籤",
        text = {
          "當前每擁有{C:money}$#2#{}",
          "使你獲得{C:money}$#1#{}",
          "{C:inactive}(可獲得{C:money}$#3#{C:inactive})"
        }
      },
      tag_paperback_divination = {
        name = "占卜標籤",
        text = {
          "獲得一個免費的",
          "{C:paperback_minor_arcana}超級秘儀包"
        }
      },
      tag_paperback_dichrome = {
        name = "雙色標籤",
        text = {
          "商店裡的下一張",
          "基礎版本小丑牌",
          "將會免費且變為{C:dark_edition}雙色"
        }
      },
      tag_paperback_high_risk = {
        name = "高風險標籤",
        text = {
          "選擇{C:attention}Boss盲注{}時",
          "將其分數",
          "需求{C:attention}翻倍{}",
          "並獲得{C:money}$#1#"
        }
      },
      tag_paperback_breaking = {
        name = "攻堅標籤",
        text = {
          "使{C:attention}Boss盲注{}",
          "限制條件消失"
        }
      }
    },
    Planet = {
      c_paperback_quaoar = {
        name = "創神星",
      },
      c_paperback_haumea = {
        name = "妊神星",
      },
      c_paperback_sedna = {
        name = "塞德娜",
      },
      c_paperback_makemake = {
        name = "鳥神星",
      },
    },
    Enhanced = {
      m_paperback_ceramic = {
        name = "陶器牌",
        text = {
          "計分時隨機",
          "獲得{C:money}$#1#{}到{C:money}$#2#{}",
          "有{C:green}#3#/#4#{}幾率",
          "被{C:mult}摧毀{}"
        }
      },
      m_paperback_soaked = {
        name = "水浸牌",
        text = {
          "{C:attention}留在手牌中{}的水浸牌",
          "為計分提供它們的{C:chips}籌碼{}",
          "{C:mult}棄牌{}時有{C:green}#1#/#2#{}幾率",
          "被{C:mult}摧毀{}",
        }
      },
      m_paperback_wrapped = {
        name = "禮品牌",
        text = {
          "計分時給予{C:money}$#1#{}",
          "無點數花色"
        }
      },
      m_paperback_bandaged = {
        name = "綁紮牌",
        text = {
          "重新觸發{C:attention}兩側{}的卡牌",
          "計分時有{C:green}#1#/#2#{}幾率",
          "被{C:mult}摧毀{}"
        }
      }
    },
    Edition = {
      e_paperback_dichrome = {
        name = "雙色",
        text = {
          "選擇{C:attention}盲注{}時",
          "{C:attention}+#1#{C:chips}出牌{}或{C:mult}棄牌{}次數",
          "{C:inactive}(較少的優先)"
        }
      }
    },
    Other = {
      paperback_energized = {
        name = "已充能",
        text = {
          "{C:attention}基本小丑能量{}",
          "無法複製此牌"
        }
      },
      paperback_light_suits = {
        name = "亮花色",
        text = {
          "{C:diamonds}方片{}、{C:hearts}紅桃{}"
        }
      },
      paperback_dark_suits = {
        name = "暗花色",
        text = {
          "{C:spades}黑桃{}、{C:clubs}梅花{}"
        }
      },
      paperback_requires_custom_suits = {
        name = "需要自訂花色",
        text = {
          "由於{C:legendary}Paperback",
          "{C:attention}自訂花色{}被禁用",
          "而無法出現在遊戲中",
        }
      },
      paperback_requires_enhancements = {
        name = "需要增強",
        text = {
          "由於{C:legendary}Paperback",
          "{C:attention}增強{}被禁用",
          "而無法出現在遊戲中",
        }
      },
      paperback_requires_paperclips = {
        name = "需要別針",
        text = {
          "由於{C:legendary}Paperback",
          "{C:attention}別針{}被禁用",
          "而無法出現在遊戲中",
        }
      },
      paperback_requires_minor_arcana = {
        name = "需要塔羅輔牌",
        text = {
          "由於{C:legendary}Paperback",
          "{C:paperback_minor_arcana}塔羅輔牌{}被禁用",
          "而無法出現在遊戲中",
        }
      },
      paperback_requires_tags = {
        name = "需要標籤",
        text = {
          "由於{C:legendary}Paperback",
          "{C:attention}標籤{}被禁用",
          "而無法出現在遊戲中",
        }
      },
      paperback_requires_editions = {
        name = "需要版本",
        text = {
          "由於{C:legendary}Paperback",
          "{C:dark_edition}版本{}被禁用",
          "而無法出現在遊戲中",
        }
      },

      -- Paperclips
      paperback_blue_clip = {
        name = "藍色別針",
        text = {
          "{C:attention}留在手牌中{}的每個{C:attention}別針{}",
          "使這個別針額外提供{X:chips,C:white}X#1#{}籌碼",
          "{C:inactive}(當前{X:chips,C:white}X#2#{C:inactive}籌碼)"
        }
      },
      paperback_red_clip = {
        name = "紅色別針",
        text = {
          "{C:attention}留在手牌中{}的每個{C:attention}別針{}",
          "使這個別針額外提供{C:mult}+#1#{}倍率",
          "{C:inactive}(當前{C:mult}+#2#{C:inactive}倍率)"
        }
      },
      paperback_orange_clip = {
        name = "橙色別針",
        text = {
          "{C:attention}留在手牌中{}的每{C:attention}#2#{}個{C:attention}別針{}",
          "使這個別針額外提供{C:money}$#1#{}",
          "{C:inactive}(當前{C:money}$#3#{C:inactive})"
        }
      },
      paperback_black_clip = {
        name = "黑色別針",
        text = {
          "除這個別針以外",
          "如果{C:attention}打出的牌{}帶有{C:attention}別針{}",
          "或{C:attention}留在手中的牌{}帶有{C:attention}別針{}",
          "各使此牌重新觸發一次"
        }
      },
      paperback_white_clip = {
        name = "白色別針",
        text = {
          "如果{C:attention}回合結束{}時仍{C:attention}留在手中",
          "本回合打出的每個{C:attention}別針{}",
          "使這個別針獲得{C:chips}+#1#{}籌碼",
          "{C:inactive}(當前{C:chips}+#2#{C:inactive}籌碼)"
        }
      },
      paperback_pink_clip = {
        name = "粉色別針",
        text = {
          "{C:attention}留在手牌中{}時提供{X:mult,C:white}X#1#{}倍率",
          "每個計分的{C:attention}別針{}使其",
          "額外提供{X:mult,C:white}X#2#{}倍率",
          "{C:inactive}(出牌結束後重置)"
        }
      },

      -- Minor Arcana
      p_paperback_minor_arcana_normal = {
        name = "秘儀包",
        text = {
          "從最多{C:attention}#2#{}張{C:paperback_minor_arcana}塔羅輔牌{}中",
          "選擇{C:attention}#1#{}張",
          "即選即用"
        }
      },
      p_paperback_minor_arcana_jumbo = {
        name = "巨型秘儀包",
        text = {
          "從最多{C:attention}#2#{}張{C:paperback_minor_arcana}塔羅輔牌{}中",
          "選擇{C:attention}#1#{}張",
          "即選即用"
        }
      },
      p_paperback_minor_arcana_mega = {
        name = "超級秘儀包",
        text = {
          "從最多{C:attention}#2#{}張{C:paperback_minor_arcana}塔羅輔牌{}中",
          "選擇{C:attention}#1#{}張",
          "即選即用"
        }
      },
    },
  },
  misc = {
    dictionary = {
      -- Badge under cards
      k_paperback_minor_arcana = "塔羅輔牌",
      -- Name of consumable type in collection
      b_paperback_minor_arcana_cards = "塔羅輔牌",
      -- Text shown at the bottom while opening booster
      paperback_minor_arcana_pack = "秘儀包",

      paperback_polychrome_ex = "多彩！",
      paperback_destroyed_ex = "被毀！",
      paperback_doubled_ex = "翻倍！",
      paperback_too_late_ex = "太晚了！",
      paperback_broken_ex = "損壞！",
      paperback_none = "沒有",
      paperback_downgrade_ex = "降級！",
      paperback_copy_ex = "複製！",
      paperback_consumed_ex = "吃完了！",
      paperback_too_hot_ex = "太熱！",
      paperback_inactive = "不生效",
      paperback_supplies_ex = "補給！",
      paperback_melted_ex = "融化了！",
      paperback_investment_ex = "投資！",
      paperback_plus_minor_arcana = "+1塔羅輔牌",
      paperback_plus_consumable = "+1消耗牌",
      paperback_edition_ex = "版本！",

      paperback_ui_requires_restart = "需要重啟",
      paperback_ui_enable_jokers = "啟用小丑",
      paperback_ui_enable_minor_arcana = "啟用塔羅輔牌",
      paperback_ui_enable_enhancements = "啟用增強",
      paperback_ui_enable_editions = "啟用版本",
      paperback_ui_enable_paperclips = "啟用別針",
      paperback_ui_custom_suits_enabled = "啟用自訂花色",
      paperback_ui_enable_vouchers = "啟用優惠券",
      paperback_ui_enable_tags = "啟用標籤",
      paperback_ui_developers = "開發者",
      paperback_ui_artists = "畫師",
      paperback_ui_localization = "翻譯",
      paperback_ui_paperclips = "別針",
    },
    v_dictionary = {
      paperback_a_discards = "+#1#棄牌次數",
      paperback_a_discards_minus = "-#1#棄牌次數",
      paperback_a_hands_minus = "-#1#出牌次數",
      paperback_prince_of_darkness = "+#1#倍率，+#2#籌碼",
      paperback_a_completion = "#1#/#2#",
      paperback_a_round_minus = "-#1#回合"
    },
    suits_singular = {
      paperback_Crowns = "皇冠",
      paperback_Stars = '銀星'
    },
    suits_plural = {
      paperback_Crowns = "皇冠",
      paperback_Stars = '銀星'
    },
    poker_hands = {
      ['paperback_Spectrum'] = "光譜",
      ['paperback_Straight Spectrum'] = "光譜順子",
      ['paperback_Straight Spectrum (Royal)'] = "皇家光譜",
      ['paperback_Spectrum House'] = "光譜葫蘆",
      ['paperback_Spectrum Five'] = "光譜五條",
    },
    poker_hand_descriptions = {
      ['paperback_Spectrum'] = {
        "花色不同的5張牌"
      },
      ['paperback_Straight Spectrum'] = {
        "花色不同、點數連續的5張牌"
      },
      ['paperback_Spectrum House'] = {
        "每張牌花色均不同的三條加對子"
      },
      ['paperback_Spectrum Five'] = {
        "花色不同、點數相同的5張牌",
      },
    },
    labels = {
      paperback_blue_clip = "藍色別針",
      paperback_red_clip = "紅色別針",
      paperback_orange_clip = "橙色別針",
      paperback_pink_clip = "粉色別針",
      paperback_black_clip = "黑色別針",
      paperback_white_clip = "白色別針",
      paperback_dichrome = "雙色",
    }
  }
}
