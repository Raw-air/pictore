return {
  jokers_enabled = true,
  minor_arcana_enabled = true,
  suits_enabled = true,
  enhancements_enabled = true,
  editions_enabled = true,
  paperclips_enabled = true,
  vouchers_enabled = true,
  tags_enabled = true,
}
