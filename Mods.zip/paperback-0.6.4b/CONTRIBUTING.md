# Contributing

- Join the [Discord](https://discord.gg/uhqx4Yr33j)

- Let us know what you are working on (for the spreadsheet)

- Fork the repo (or create a branch if you're invited)

- Be sure to check out our [Custom Contexts](https://github.com/GitNether/paperback/wiki/Custom-Contexts) and [Paperback Config](https://github.com/GitNether/paperback/wiki/Paperback-Config) wiki pages, which may be helpful on your contribution

- Open a PR once finished
