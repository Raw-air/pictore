PB_UTIL.Planet {
  key = 'haumea',
  atlas = 'planets_atlas',
  pos = { x = 1, y = 0 },
  discovered = true,
  unlocked = true,
  is_dwarf = true,
  config = {
    hand_type = 'paperback_Straight Spectrum',
    softlock = true,
  }
}
