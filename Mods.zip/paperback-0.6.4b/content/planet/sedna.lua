PB_UTIL.Planet {
  key = 'sedna',
  atlas = 'planets_atlas',
  pos = { x = 2, y = 0 },
  discovered = true,
  unlocked = true,
  is_dwarf = true,
  config = {
    hand_type = 'paperback_Spectrum House',
    softlock = true,
  }
}
