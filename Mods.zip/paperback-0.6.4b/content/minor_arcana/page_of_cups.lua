PB_UTIL.MinorArcana {
  key = 'page_of_cups',
  config = {
    paperclip = 'white',
    max_highlighted = 2
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 3, y = 1 },
  paperback = {
    requires_paperclips = true
  }
}
