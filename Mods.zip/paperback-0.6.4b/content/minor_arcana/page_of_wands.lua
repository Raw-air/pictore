PB_UTIL.MinorArcana {
  key = 'page_of_wands',
  config = {
    paperclip = 'orange',
    max_highlighted = 3
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 3, y = 3 },
  paperback = {
    requires_paperclips = true
  }
}
