PB_UTIL.MinorArcana {
  key = 'four_of_wands',
  config = {
    paperclip = 'pink',
    max_highlighted = 3
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 3, y = 2 },
  paperback = {
    requires_paperclips = true
  }
}
