PB_UTIL.MinorArcana {
  key = 'ace_of_wands',
  config = {
    paperclip = 'red',
    max_highlighted = 2
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 0, y = 2 },
  paperback = {
    requires_paperclips = true
  }
}
