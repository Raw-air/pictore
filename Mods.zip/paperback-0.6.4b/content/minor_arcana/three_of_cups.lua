PB_UTIL.MinorArcana {
  key = 'three_of_cups',
  config = {
    paperclip = 'black',
    max_highlighted = 3
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 2, y = 0 },
  paperback = {
    requires_paperclips = true
  }
}
