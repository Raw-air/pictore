PB_UTIL.MinorArcana {
  key = 'ace_of_cups',
  config = {
    paperclip = 'blue',
    max_highlighted = 2
  },
  atlas = 'minor_arcana_atlas',
  pos = { x = 0, y = 0 },
  paperback = {
    requires_paperclips = true
  }
}
