PB_UTIL.MinorArcanaBooster {
  key = 'minor_arcana_normal_1',
  atlas = 'boosters_atlas',
  pos = { x = 0, y = 0 },
  config = {
    extra = 3,
    choose = 1
  },
  weight = 1,
  cost = 4,
  discovered = true,
}
