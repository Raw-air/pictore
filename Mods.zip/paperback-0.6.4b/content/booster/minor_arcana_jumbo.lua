PB_UTIL.MinorArcanaBooster {
  key = 'minor_arcana_jumbo',
  atlas = 'boosters_atlas',
  pos = { x = 2, y = 0 },
  config = {
    extra = 5,
    choose = 1
  },
  weight = 1,
  cost = 6,
  discovered = true,
}
