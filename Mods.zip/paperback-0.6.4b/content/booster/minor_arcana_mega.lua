PB_UTIL.MinorArcanaBooster {
  key = 'minor_arcana_mega',
  atlas = 'boosters_atlas',
  pos = { x = 3, y = 0 },
  config = {
    extra = 5,
    choose = 2
  },
  weight = 0.25,
  cost = 8,
  discovered = true,
}
