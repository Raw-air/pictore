return {
	["misc"] = {
		["dictionary"] = {
			["k_rotten_ex"] = "腐朽！",
			["k_buried_ex"] = "埋葬！",
			["k_invalid_ex"] = "無效！",
			["k_blam_ex"] = "轟！",
			["k_bonus"] = "獎勵！",
			["k_end_ex"] = "喀嗒！",
			["k_mult"] = "倍率！",
			["b_take"] = "拿取",
			["k_dig_ex"] = "挖掘。",
			["Chips"] = "籌碼",
			['k_tma_audio_pack'] = '音檔包',
			},
		["poker_hands"] = {
			["dead"] = "亡命之手",
			["tma_dead"] = "亡命之手",
		},
		["poker_hand_descriptions"] = {
			["dead"] = {
				"2對黑色A和黑色8，並且",
				"牌組中有神射手",
			},
			["tma_dead"] = {
				"2對黑色A和黑色8，並且",
				"牌組中有神射手",
			},
		}
	},
	["descriptions"] = {
		["Tarot"] = {
			["c_tma_the_rot"] = {
				["name"] = "腐朽",
				["text"] = {
					"創造{C:attention}1{}張隨機",
					"{C:dark_edition}負片 {C:tarot}塔羅牌{}",
				},
			}
		},
		["Spectral"] = {
			["c_tma_decay"] = {
				["name"] = "腐化",
				["text"] = {
					"創造一個{C:dark_edition}負片",
					"{C:attention}易逝{}的隨機",
					"{C:attention}小丑{}副本",
				},
			},
			["c_tma_compulsion"] = {
				["name"] = "強迫",
				["text"] = {
					"當{C:attention}啟用{}時，",
					"重新觸發所有{C:attention}小丑{}",
				},
			},
		},
		["Planet"] = {
			["c_tma_colony"] = {
				["name"] = "聚落",
				["text"] = {
					"提升最常使用的",
					"{C:attention}撲克牌型",
					"{C:attention}1{}個等級",
				},
			}
		},
		["Statement"] = {
			["c_tma_nightfall"] = {
				["name"] = "夜幕降臨",
				["text"] = {
					"當{C:attention}啟用{}時，所有打出的",
					"{C:spades}黑桃{}和{C:clubs}梅花{}牌",
					"在得分時變成",
					"{C:attention}獎勵{}牌",
				},
			},
			["c_tma_burnout"] = {
				["name"] = "燃燒殆盡",
				["text"] = {
					"當{C:attention}啟用{}時，所有打出的",
					"{C:hearts}紅心{}和{C:diamonds}方塊{}牌",
					"在得分時變成",
					"{C:attention}倍率{}牌",
				},
			},
			["c_tma_parity"] = {
				["name"] = "平衡",
				["text"] = {
					"當{C:attention}啟用{}時，{C:attention}奇數{}牌",
					"在得分時給予{C:chips}+#1#{}籌碼，",
					"{C:attention}偶數{}牌給予",
					"{C:mult}+#2#{}倍率",
				},
			},
			["c_tma_wonderland"] = {
				["name"] = "仙境",
				["text"] = {
					"當{C:attention}啟用{}時，得分",
					"卡牌給予等同其",
					"點數的{C:mult}倍率{}",
				},
			},
			["c_tma_precipice"] = {
				["name"] = "懸崖",
				["text"] = {
					"當{C:attention}啟用{}時，提升",
					"所有打出的{C:attention}撲克牌型{}",
				},
			},
			["c_tma_mystery"] = {
				["name"] = "謎團",
				["text"] = {
					"當{C:attention}啟用{}時，棄牌時",
					"創造一張隨機",
					"{C:tarot}塔羅牌{}",
					"{C:inactive}(必須有空間)",
				},
			},
			["c_tma_research"] = {
				["name"] = "研究",
				["text"] = {
					"當{C:attention}啟用{}時，",
					"重新觸發所有得分的",
					"{C:attention}數字牌{}",
				},
			},
			["c_tma_preserve"] = {
				["name"] = "保存",
				["text"] = {
					"當{C:attention}啟用{}時，所有卡牌",
					"無法被{C:attention}削弱{}",
				},
			},
			["c_tma_morph"] = {
				["name"] = "變形",
				["text"] = {
					"當{C:attention}啟用{}時，{C:attention}百搭{}",
					"卡視為所有{C:attention}點數{}",
				},
			},
			["c_tma_paradise"] = {
				["name"] = "寧靜",
				["text"] = {
					"當{C:attention}啟用{}時，使",
					"所有獲得的{C:money}金錢{}加倍",
				},
			},
			["c_tma_divinity"] = {
				["name"] = "神威",
				["text"] = {
					"當{C:attention}啟用{}時，{C:white,X:mult}X#1#{}倍率，",
					"基於此卡在{C:attention}持有{}狀態下",
					"經過的回合數",
					"{C:inactive}(目前 {C:white,X:mult}X#2#{C:inactive} 倍率)",
				},
			},
			["c_tma_indulgence"] = {
				["name"] = "放縱",
				["text"] = {
					"當{C:attention}啟用{}時，花費{C:money}$#1#",
					"以在沒有棄牌次數時",
					"{C:red}棄掉{}手牌",
				},
			},
			["c_tma_glimmer"] = {
				["name"] = "微光",
				["text"] = {
					"當{C:attention}啟用{}時，所有{C:attention}小丑{}",
					"在此盲注獲得隨機",
					"{C:attention}版本{}",
				},
			},
			["c_tma_static"] = {
				["name"] = "靜止",
				["text"] = {
					"當{C:attention}啟用{}時，所有得分",
					"卡牌在打出後",
					"返回{C:attention}手牌{}",
				},
			},
			["c_tma_exhaustion"] = {
				["name"] = "精疲力竭",
				["text"] = {
					"當{C:attention}啟用{}時，摧毀",
					"{C:attention}得分手牌{}中的所有卡牌",
				},
			},
		},
		["Enhanced"] = {
			["m_tma_rotting"] = {
				["name"] = "腐朽牌",
				["text"] = {
					"{C:mult}+#1#{}倍率",
					"打出時失去",
					"{C:mult}+#2#{}倍率",
				}
			}
		},
		["Joker"] = {
			["j_tma_NowhereToGo"] = {
				["name"] = "挖掘。",
				["text"] = {
					"本回合每得分一張",
					"{C:spades}黑桃{}牌，降低",
					"{C:attention}盲注需求{}{C:white,X:chips}#1#%{}",
				},
			},
			["j_tma_PlagueDoctor"] = {
				["name"] = "瘟疫醫生",
				["text"] = {
					"在{C:attention}商店{}結束時",
					"{C:purple}腐朽{}你持有的",
					"所有{C:attention}消耗品{}卡牌",
				},
			},
			["j_tma_BlindSun"] = {
				["name"] = "日蝕",
				["text"] = {
					"{C:green}#1#/#2#{}的卡牌",
					"被面朝下抽取，",
					"面朝下的卡牌得分時",
					"給予{C:mult}+#3#{}倍率",
				},
			},
			["j_tma_LightlessFlame"] = {
				["name"] = "無光之焰",
				["text"] = {
					"選擇{C:attention}盲注{}時，",
					"摧毀持有的{C:attention}消耗品{}卡",
					"並為每張卡獲得",
					"{C:mult}+#2#{}倍率",
					"{C:inactive}(目前 {C:mult}+#1#{C:inactive} 倍率)",
				},
			},
			["j_tma_LastLaugh"] = {
				["name"] = "最後一笑",
				["text"] = {
					"如果{C:attention}牌組{}中沒有",
					"更多卡牌，獲得",
					"{X:mult,C:white}X#1#{}倍率",
				},
			},
			["j_tma_Panopticon"] = {
				["name"] = "全景監獄",
				["text"] = {
					"本局使用的每張",
					"不同{C:spectral}靈界{}卡片",
					"給予{C:chips}+#1#{}籌碼",
					"{C:inactive}(目前 {C:chips}+#2#{C:inactive} 籌碼)",
				},
			},
			["j_tma_Boneturner"] = {
				["name"] = "骨匠",
				["text"] = {
					"{C:attention}K{}、{C:attention}Q{}和",
					"{C:attention}J{}視為",
					"相同{C:attention}點數{}",
					"{C:inactive, s:0.8}(可能與其他模組不相容)",
				},
			},
			["j_tma_FallenTitan"] = {
				["name"] = "墮落巨人",
				["text"] = {
					"手中持有的每張",
					"{C:attention}石頭{}牌給予",
					"{C:chips}+#1#{}籌碼",
				},
			},
			["j_tma_Lonely"] = {
				["name"] = "孤獨小丑",
				["text"] = {
					"如果打出手牌是{C:attention}#3#{}",
					"此小丑獲得{C:mult}+#1#{}倍率",
					"{C:inactive}(目前 {C:mult}+#2#{C:inactive} 倍率)",
				},
			},
			["j_tma_Distortion"] = {
				["name"] = "扭曲",
				["text"] = {
					"{C:chips,E:1}它{E:1}並非其所是",
				},
			},
			["j_tma_Nikola"] = {
				["name"] = "尼古拉",
				["text"] = {
					"重新觸發所有",
					"{C:red}稀有{C:attention}小丑{}",
				},
			},
			["j_tma_Hunter"] = {
				["name"] = "獵手",
				["text"] = {
					"打出的{C:attention}封印{}卡牌",
					"得分時給予{C:money}$#1#{}",
				}
			},
			["j_tma_MrSpider"] = {
				["name"] = "蜘蛛先生",
				["text"] = {
					"如果第一手牌是單張{C:attention}#3#{}，",
					"摧毀它並獲得{C:white,X:mult}X#1#{}倍率，",
					"{s:0.8}點數每回合改變",
					"{C:inactive}(目前 {C:white,X:mult}X#2#{C:inactive} 倍率)",
				}
			},
			["j_tma_Extinction"] = {
				["name"] = "滅絕",
				["text"] = {
					"如果你的完整牌組",
					"少於{C:attention}#2#{}張卡牌",
					"獲得{X:mult,C:white}X#1#{}倍率",
				}
			},
			["j_tma_Piper"] = {
				["name"] = "花衣吹笛人",
				["text"] = {
					"{C:attention}+#1#{}手牌上限，",
					"打出手牌時棄掉",
					"{C:attention}#2#{}張隨機卡牌",
				}
			},
			["j_tma_Coffin"] = {
				["name"] = "棺材",
				["text"] = {
					"購買時給予{C:money}$#1#{}，",
					"出售時摧毀相鄰的",
					"{C:attention}小丑{}",
				}
			},
			["j_tma_Syringe"] = {
				["name"] = "注射器",
				["text"] = {
					"{C:attention}出售{}此卡以將",
					"{C:blue}手牌{}設為1並降低",
					"{C:attention}盲注需求{}{X:chips,C:white}80%{}",
				}
			},
			["j_tma_ShadowPuppet"] = {
				["name"] = "影子木偶",
				["text"] = {
					"每回合使用的第一張",
					"{C:tarot}塔羅牌{}會創造",
					"一個{C:dark_edition}負片{}副本",
				}
			},
			["j_tma_Wildfire"] = {
				["name"] = "野火",
				["text"] = {
					"{C:green}#1#/#2#{}的{C:attention}百搭{}牌",
					"得分後轉換",
					"相鄰的卡牌",
				}
			},
			["j_tma_Gunslinger"] = {
				["name"] = "神射手",
				["text"] = {
					"{C:attention}#1#{}算作",
					"{C:attention}亡命之手{}",
					"{C:red,E:2}自我毀滅{}",
				}
			},
			["j_tma_MechanicalJoker"] = {
				["name"] = "機械小丑",
				["text"] = {
					"{C:attention}重新觸發{}相鄰的",
					"普通小丑",
				}
			},
			["j_tma_Archivist"] = {
				["name"] = "錄音機",
				["text"] = {
					"回合結束時，獲得等同於",
					"持有的每個{C:attention}消耗品{}的",
					"{C:attention}3倍{}售價的{C:chips}籌碼{}",
					"{C:inactive}(目前 {C:chips}+#1#{C:inactive} 籌碼)",
				}
			},
			["j_tma_Heartbeat"] = {
				["name"] = "脈動",
				["text"] = {
					"{C:attention}重新觸發{}所有",
					"打出的{C:heart}紅心{}牌",
					"當得分時",
				}
			},
			["j_tma_LostCity"] = {
				["name"] = "失落之城",
				["text"] = {
					"每回合{C:red}#1#{}棄牌次數，",
					"若棄掉手牌包含",
					"{C:attention}黃金{}牌，{C:red}+#2#{}棄牌次數",
				}
			},
			["j_tma_Lighthouse"] = {
				["name"] = "燈塔",
				["text"] = {
					"{C:attention}強化{}卡牌",
					"無法被{C:attention}削弱{}",
				}
			},
			["j_tma_WarChant"] = {
				["name"] = "戰歌",
				["text"] = {
					"如果打出的手牌是",
					"本回合第一手牌",
					"給予{C:mult}+#1#{}倍率",
				}
			},
			["j_tma_Fractal"] = {
				["name"] = "分形",
				["text"] = {
					"{C:clubs}梅花{}牌為每張",
					"打出的得分{C:clubs}梅花{}牌",
					"給予{C:white,X:mult}X#1#{}倍率",
				}
			},
			["j_tma_Mannequin"] = {
				["name"] = "人體模型",
				["text"] = {
					"{C:attention}出售{}此卡以創造",
					"最後移除的{C:attention}小丑{}",
					"或{C:statement}卡帶{}的副本",
					"{s:0.8}不包括{C:attention,s:0.8}人體模型",
					"{C:inactive}(目前 {C:attention}#1#{C:inactive})",
				}
			},
			["j_tma_DeepBlue"] = {
				["name"] = "深藍",
				["text"] = {
					"{C:attention}手中持有{}",
					"的卡牌給予{C:chips}籌碼{}",
				}
			},
			["j_tma_Marionette"] = {
				["name"] = "操偶師",
				["text"] = {
					"每當左側的",
					"{C:attention}小丑{}被觸發時",
					"給予{C:mult}+#1#{}倍率",
				}
			},
		},
		["Other"] = {
			["p_tma_audio_basic1"]	= {
				["group_name"] = "音檔包",
				["name"] = "音檔包",
				["text"] = {
					"從最多{C:attention}#2#{}張",
					"{C:statement}卡帶{}中選擇{C:attention}#1#{}張",
					"加入消耗品",
				}
			},
			["p_tma_audio_basic2"]	= {
				["group_name"] = "音檔包",
				["name"] = "音檔包",
				["text"] = {
					"從最多{C:attention}#2#{}張",
					"{C:statement}卡帶{}中選擇{C:attention}#1#{}張",
					"加入消耗品",
				}
			},
			["p_tma_audio_jumbo"]	= {
				["group_name"] = "音檔包",
				["name"] = "巨型音檔包",
				["text"] = {
					"從最多{C:attention}#2#{}張",
					"{C:statement}卡帶{}中選擇{C:attention}#1#{}張",
					"加入消耗品",
				}
			},
			["p_tma_audio_mega"]	= {
				["group_name"] = "音檔包",
				["name"] = "超級音檔包",
				["text"] = {
					"從最多{C:attention}#2#{}張",
					"{C:statement}卡帶{}中選擇{C:attention}#1#{}張",
					"加入消耗品",
				}
			},
		},
	},
}