A mod inspired by the Magnus Archives

Website/Wiki Page: https://lunaastracassiopeia.github.io
