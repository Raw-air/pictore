# A Balatro Multiplayer Mod

How to install: https://balatromp.com/docs/getting-started/installation

Join the discord server for support: https://discord.gg/balatromp

## Licenced under [GNU GPL 3.0](https://github.com/V-rtualized/balatro-multiplayer/blob/main/LICENSE.md)
