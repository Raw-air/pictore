SMODS.Challenge({
	key = "psychosis",
	jokers = {
		{ id = "j_madness", eternal = true },
	},
	unlocked = function(self)
		return true
	end,
})
