SMODS.Challenge({
	key = "speed",
	jokers = {
		{ id = "j_mp_conjoined_joker", eternal = true, edition = "negative" },
		{ id = "j_mp_speedrun", eternal = true, edition = "negative" },
	},
	unlocked = function(self)
		return true
	end,
})
