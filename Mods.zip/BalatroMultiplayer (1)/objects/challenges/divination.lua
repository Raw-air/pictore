SMODS.Challenge({
	key = "divination",
	jokers = {
		{ id = "j_vagabond", eternal = true },
	},
	unlocked = function(self)
		return true
	end,
})
