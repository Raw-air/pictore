SMODS.Challenge({
	key = "twin_towers",
	jokers = {
		{ id = "j_obelisk", eternal = true },
		{ id = "j_obelisk", eternal = true },
	},
	unlocked = function(self)
		return true
	end,
})
