SMODS.Challenge({
	key = "skip_off",
	jokers = {
		{ id = "j_mp_skip_off", eternal = true },
		{ id = "j_throwback", eternal = true },
	},
	unlocked = function(self)
		return true
	end,
})
