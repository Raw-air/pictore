--[[MP.Ruleset({
	key = "weekly",
})]]
