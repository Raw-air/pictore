return {
    descriptions = {
        Other = {
            load_success = {
                text = {
                    '模組載入{C:green}成功！'
                }
            },
            load_failure_d = {
                text = {
                    '{C:attention}依賴項{}缺失！',
                    '#1#'
                }
            },
            load_failure_c = {
                text = {
                    '存在{C:attention}衝突項{}！',
                    '#1#'
                }
            },
            load_failure_d_c = {
                text = {
                    '{C:attention}依賴項{}缺失！',
                    '#1#',
                    '存在{C:attention}衝突項{}！',
                    '#2#'
                }
            },
            load_failure_o = {
                text = {
                    'Steamodded版本{C:attention}過舊{}！',
                    '已不再支持',
                    '{C:money}0.9.8{}及以下版本'
                }
            },
            load_failure_i = {
                text = {
                    '{C:attention}不相容！',
                    '所需Steamodded版本為#1#',
                    '但當前為#2#'
                }
            },
            load_failure_p = {
                text = {
                    '{C:attention}首碼衝突！{}',
                    '此模組的首碼和',
                    '另外一個模組相同！',
                    '({C:attention}#1#{})'
                }
            },
            load_failure_m = { -- To be translated
                text = {
                    '{C:attention}Main File Not Found!{}',
                    'This mod\'s main file',
                    'could not be found.',
                    '({C:attention}#1#{})'
                }
            },
            load_disabled = {
                text = {
                    '該模組',
                    '已被{C:attention}禁用{}！'
                }
            }
        },
        Edition = {
            e_negative_playing_card = {
                name = "負片",
                text = {
                    "手牌上限{C:dark_edition}+#1#"
                },
            },
        }
    },
    misc = {
        achievement_names = {
            hidden_achievement = "???",
        },
        achievement_descriptions = {
            hidden_achievement = "未發現",
        },
        dictionary = {
            b_mods = '模組',
            b_mods_cap = '模組',
            b_modded_version = '模組環境！',
            b_steamodded = 'Steamodded',
            b_credits = '鳴謝',
            b_open_mods_dir = '打開模組目錄',
            b_no_mods = '未檢測到任何模組……',
            b_mod_list = '已啟用模組列表',
            b_mod_loader = '模組載入器',
            b_developed_by = '作者：',
            b_rewrite_by = '重寫者：',
            b_github_project = 'Github項目',
            b_github_bugs_1 = '你可以在此彙報漏洞',
            b_github_bugs_2 = '和提交貢獻',
            b_disable_mod_badges = '禁用模組橫標',
            b_author = '作者',
            b_authors = '作者',
            b_unknown = '未知',
            b_lovely_mod = '(依賴Lovely載入器的補丁模組)',
            b_by = ' 作者：',
            b_config = "配置",
            b_additions = '新增項目',
            b_stickers = '貼紙',
            b_achievements = "成就",
            b_applies_stakes_1 = '',
            b_applies_stakes_2 = '的限制也都起效',
            b_graphics_mipmap_level = "多級漸遠紋理層級",
        },
        v_dictionary = {
            c_types = '共有#1#種',
            cashout_hidden = '……還有#1#',
        },
    },

}


