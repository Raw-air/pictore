return {
    descriptions = {
        -- this key should match the set ("object type") of your object,
        -- e.g. Voucher, Tarot, or the key of a modded consumable type
        Joker = {
            -- this should be the full key of your object, including any prefixes
            j_hnds_color_of_madness = {
                name = '星之彩',
                text = {
                    '如果{C:attention}第一次出牌{}',
                    '包含{C:attention}4{}種不同的花色',
                    '則將{C:attention}第一張{}計分卡',
                    '變成{C:attention}萬能牌{}'
                }
                -- only needed when this object is locked by default
                -- unlock = {
                --'This is a condition',
                --'for unlocking this card',
                --},
            },
            j_hnds_occultist = {
                name = '神秘學家',
                text = {
                    '如果{C:attention}第一次出牌{}',
                    '包含{C:attention}4{}種不同的花色',
                    '則創造一個{C:planet}流星{},',
                    '{C:tarot}吊飾{}或{C:spectral}空靈{}{C:attention}標籤{}',
                }
            },
            j_hnds_banana_split = {
                name = '香蕉聖代',
                text = {
                    '{X:mult,C:white}X#1#{}倍率',
                    '回合結束時',
		    '有{C:green}#2#/#3#{}的概率',
                    '{C:attention}複製{}這張牌',
                    '{C:inactive}(必須有空間){}',
                }
            },
            j_hnds_head_of_medusa = {
                name = '美杜莎之首',
                text = {
                    '每當{C:attention}人頭牌{}計分時',
                    '這張小丑牌獲得{X:mult,C:white}X#2#{}倍率',
                    '將計分的{C:attention}人頭牌{}變為{C:attention}石頭牌{}',
                    '{C:inactive}(當前為{X:mult,C:white}X#1#{C:inactive}倍率)'
                }
            },
            j_hnds_deep_pockets = {
                name = '財布鼓鼓',
                text = {
                    '消耗牌槽位{C:attention}+#1#{}',
                    '你{C:attention}消耗牌欄位{}中的',
                    '每張卡給予{C:mult}+#2#{}倍率',
                }
            },
            j_hnds_digital_circus = {
                name = '數字馬戲團',
                text = {
                    '售出此卡以創建一張',
                    '帶有隨機{C:attention}版本{}的{V:1}#1#{}小丑牌',
                    '每{C:attention}#3#{}個回合都會提升其稀有度',
                    '{C:inactive}(當前為第{C:attention}#2#{C:inactive}/#3#個回合)'
                }
            },
            j_hnds_coffee_break = {
                name = '咖啡小憩',
                text = {
                    '{C:attention}2{}個回合後',
                    '售出此卡可獲得{C:money}$#3#{}',
                    '你每打出一張牌',
		    '此金額減少{C:money}$1{}',
                    '{C:inactive}(當前為第{C:attention}#2#{C:inactive}/#1#個回合)'
                },
            },
            j_hnds_jackpot = {
                name = "頭獎",
                text = {
                    '回合結束時',
		    '這張牌有{C:green}#1#/#2#{}的幾率',
                    '贏得{C:money}$#3#{}並{C:red}自毀{}',
		    '每當一張打出的{C:attention}7{}計分時',
                    '此{C:green}概率{}增加{C:green}#4#/#2#{} ',
                }
            },
            j_hnds_pot_of_greed = {
                name = "強欲之壺",
                text = {
                    '每當你使用一張{C:attention}消耗牌{}時',
                    '抽{C:attention}#1#{}張牌',
                }
            },
            j_hnds_seismic_activity = {
                name = "震測作業",
                text = {
                    '重新觸發所有',
                    '{C:attention}石頭牌'
                }
            },
            j_hnds_stone_mask = {
                name = "石鬼面",
                text = {
                    '如果{C:attention}第一次出牌{}',
                    '只有一張{C:attention}增強牌{}',
                    '為其添加隨機的{C:attention}版本{}',
                }
            },
            j_hnds_jokestone = {
                name = "醜石傳說",
                text = {
                    '回合開始時',
                    '抽取最多{C:attention}3{}張{C:attention}增強牌{}',
                }
            },
            j_hnds_meme = {
                name = "網路迷因",
                text = {
                    '你打出的手牌中每有一種{C:attention}花色{}',
                    '這張小丑牌獲得{X:mult,C:white}X0.05{}倍率',
                    '{C:inactive}(當前為{X:mult,C:white}X#1#{C:inactive}倍率)',
                }
            },
            j_hnds_balloons = {
                name = "氣球",
                text = {
                    "如果回合結束時",
		    "你恰好沒有出牌次數",
                    "{C:red}失去{}一個{C:attention}氣球{}",
                    "並創建一個隨機的{C:attention}標籤",
                    "{C:inactive}(還剩{C:attention}#1#{C:inactive}/#2#個！)"
                }
            },
            j_hnds_jokes_aside = {
                name = "小丑靠邊站！",
                text = {
                    '本回合中',
                    '每有一張小丑牌被{C:attention}售出{}',
                    '這張小丑牌獲得{X:mult,C:white}X#2#{}倍率',
                    '{C:inactive}(當前為{X:mult,C:white}X#1#{C:inactive}倍率)'
                }
            },
        },
        Spectral = {
            c_hnds_abyss = {
                name = '深淵',
                text = {
                    '給你手牌中的',
                    '{C:attention}1{}張所選卡牌',
                    '加上{C:dark_edition}黑色蠟封{}'
                }
            },
            c_hnds_growth = {
                name = 'Growth',
                text = {
                    '給你手牌中的',
                    '{C:attention}1{}張所選卡牌',
                    '加上{C:green}綠色蠟封{}'
                }
            },
            c_hnds_petrify = {
                name = '石化',
                text = {
                    '將你手中所有的{C:attention}人頭牌{}',
                    '變為{C:attention}石頭牌{},',
                    '每石化一張牌便獲得{C:money}$5{}'
                }
            },
            c_hnds_exchange = {
                name = '交易',
                text = {
                    '給{C:attention}2{}張所選卡牌',
                    '加上{C:dark_edition}負片{}',
                    "{C:blue}-#2#{}出牌次數",
                }
            },
            c_hnds_hallows = {
                name = '聖徒',
                text = {
                    "摧毀除最左邊外的所有小丑牌",
                    "獲得{C:attention}X#1#{}倍售價的{C:money}${}",
                    "{C:inactive}(最高{C:money}$#2#{C:inactive})",
                    "{C:inactive}(當前為{C:money}$#3#{C:inactive})",
                }
            },
            c_hnds_dream = {
                name = '夢',
                text = {
                    "創建{C:attention}10{}個隨機的",
                    "{C:attention}小丑標籤{}"
                }
            },
        },
        Other = {
            hnds_black_seal = {
                name = '黑色蠟封',
                text = {
                    '這張牌在手牌中時',
                    '也會參與計分'
                }
            },
            hnds_green_seal = {
                name = '綠色蠟封',
                text = {
                    '當此卡被{C:attention}計分{}',
                    '或{C:attention}棄掉{}時',
                    '額外抽{C:attention}2{}張牌'
                }
            }
        },
        Voucher = {
            v_hnds_tag_hunter={
                name="標籤獵人",
                text={
                    "當{C:attention}Boss盲注{}被擊敗時",
                    "創建一個隨機的{C:attention}標籤{}",
                },
            },
            v_hnds_hashtag_skip={
                name="#2#跳過",
                text={
                    "你每跳過{C:attention}#1#{}個{C:attention}盲注{}",
                    "{C:attention}-1{}底注"
                },
            },
            v_hnds_beginners_luck = {
                name = "新手運",
                text = {
                    "將所有以{C:attention}數字標注{}出的",
                    "{C:green,E:1,S:1.1}幾率{}翻倍",
                    "{C:inactive}(例如：{C:green}1/3{}幾率{C:inactive} -> {C:green}2/3{}幾率{C:inactive})",
                },
            },
            v_hnds_rigged = {
                name = '出千',
                text = {
                    "將所有以{C:attention}數字標注{}出的",
                    "{C:green,E:1,S:1.1}幾率{}翻{C:attention}X1.5{}倍",
                    "{C:inactive}(例如：{C:green}2/6{}幾率{C:inactive} -> {C:green}3/6{}幾率{C:inactive})",
                },
            }
        },
        Planet={
            c_hnds_makemake={
                name="石頭海神星",
                text={
                    "{S:0.8}({S:0.8,V:1}等級#1#{S:0.8}){}",
                    "升級{C:attention}#2#",
                    "{C:chips}+#4#{}籌碼，本底注中",
                    "每次{C:attention}石頭牌{}被計分",
                    "都會額外{C:chips}+#6#{}籌碼",
		    "{C:inactive}(已計分#5#次)"
                },
            },
        }
    },
    misc = {
        dictionary = {
            k_hnds_petrified = "石化！",
            k_hnds_goldfish = "金魚！",
            k_hnds_green = "抽牌！",
            k_hnds_jackpot = "頭獎！",
            k_hnds_probinc = "增加！",
            k_hnds_coffee = "冷掉了！",
            k_hnds_seismic = "地震了！",
            k_hnds_awaken = "已蘇醒！",
            k_hnds_IPLAYPOTOFGREED = "我發動！...",
            k_hnds_balloons = "全沒了！",
            k_hnds_banana_split = "分裂！",
            k_hnds_color_of_madness = "瘋狂！",
            k_hnds_occultist = "研究！"
        },
        labels = {
            hnds_black_seal = "黑色蠟封",
            hnds_green_seal = "綠色蠟封"
        },
        poker_hands = {
            hnds_stone_ocean = "石之海"
        },
        poker_hand_descriptions = {
            hnds_stone_ocean = { "五張牌都是石頭牌" }
        }
    }
}
