local configDefinition = {
	["enableStoneOcean"] = true,
}

return configDefinition